document.getElementById("welcome-text").textContent = "Welcome to ChessBro!";
document.getElementById("site-description").textContent = "ChessBro is a chess game built by two high school Sophomores. Aditya Mathew and Kian Pakzad Jafarabadi. This website lets you play an AI as well having an AI help you by suggesting the best moves in your position.";
console.log(`If you see this, then I work and Rocky is a peak character in Project Hail Mary!`);

let age = "14"

console.log(`I am ${age} years old!`);